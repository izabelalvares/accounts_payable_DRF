from rest_framework import viewsets
from .models import Invoice
from .serializers import InvoiceSerializer
import requests
from django.shortcuts import render
from rest_framework.renderers import TemplateHTMLRenderer



class InvoiceViewSet(viewsets.ModelViewSet):
    queryset = Invoice.objects.all()
    serializer_class = InvoiceSerializer

    def __str__(self):
        return self.name


def Invoice(request):
    return render(request, 'home.html')

# def home(request):
#     homepage = Invoice.objects.all()
    
#     return render(request, 'home.html')