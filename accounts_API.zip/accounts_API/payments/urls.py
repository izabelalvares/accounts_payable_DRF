from django.urls import path, include
from rest_framework import routers
from api.views import InvoiceViewSet
from django.contrib import admin
# from api.views import home



# router = routers.DefaultRouter()
# router.register(r'invoices', InvoiceViewSet)
# router.register(r'home', home)


urlpatterns = [
    path('', include('api.urls')),
    path('admin/', admin.site.urls),
]
